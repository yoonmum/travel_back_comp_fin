import React from 'react';

function Admin() {
    return (
        <>
            <div class="uk-width-1-2@s uk-width-2-5@m">
                <ul class="uk-nav uk-nav-default">
                    <li class="uk-active"><a href="#">DashBoard</a></li>
                    <li><a href="#">Post</a></li>
                </ul>
            </div>
        </>
    );
}

export default Admin;